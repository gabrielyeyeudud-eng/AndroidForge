# MD Master Unlock Android (offline)

Projeto Android Studio inicial para Android, com interface escura azul-neon e banco SQLite local independente do Windows.

## Conteúdo funcional nesta versão
- Dashboard com entradas, despesas, valores pendentes de ordens e contagem de ordens.
- Cadastro local de clientes.
- Cadastro local de ordens de serviço.
- Registro manual de entradas e despesas.
- Dados persistidos no arquivo local `md_master_unlock.db` do aplicativo.
- Interface em português e funcionamento das funções principais sem internet após a instalação.

## Gerar APK
1. Instale o Android Studio em um computador Windows.
2. Abra a pasta `MD_Master_Unlock_Android` no Android Studio.
3. Aguarde o Gradle sincronizar (a primeira vez exige internet e baixar dependências).
4. Escolha **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de debug será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## Observações importantes
- Este é um primeiro app Android funcional, independente do banco de dados do Windows. Não existe sincronização entre os dois.
- O APK ainda não foi compilado nem testado em dispositivo neste ambiente, porque o Android SDK/Gradle não estão disponíveis aqui. Portanto, este ZIP é o projeto-fonte Android Studio, não um APK pronto.
- A versão atual cobre dashboard, clientes, ordens e transações. Relatórios avançados, gráficos detalhados, backup/restauração e edição/exclusão são melhorias pendentes.
