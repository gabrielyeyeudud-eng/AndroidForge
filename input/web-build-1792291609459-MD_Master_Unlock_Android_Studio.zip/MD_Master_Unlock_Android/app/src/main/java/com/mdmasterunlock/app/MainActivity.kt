package com.mdmasterunlock.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.util.Locale

private val Navy = Color(0xFF070D18)
private val Panel = Color(0xFF111D2E)
private val Blue = Color(0xFF20A5FF)
private val Muted = Color(0xFF91A6C0)
private val White = Color(0xFFF3F7FC)
private fun money(v: Double) = NumberFormat.getCurrencyInstance(Locale("pt", "BR")).format(v)

class LocalDb(ctx: Context) : SQLiteOpenHelper(ctx, "md_master_unlock.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE orders(id INTEGER PRIMARY KEY AUTOINCREMENT,customer TEXT NOT NULL,device TEXT NOT NULL,service TEXT NOT NULL,price REAL NOT NULL,paid REAL NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'Recebido',created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
        db.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,description TEXT NOT NULL,category TEXT NOT NULL,amount REAL NOT NULL,personal INTEGER NOT NULL DEFAULT 0,created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun addCustomer(name:String, phone:String) { writableDatabase.insertOrThrow("customers", null, ContentValues().apply { put("name",name); put("phone",phone) }) }
    fun addOrder(customer:String, device:String, service:String, price:Double) { writableDatabase.insertOrThrow("orders", null, ContentValues().apply { put("customer",customer); put("device",device); put("service",service); put("price",price); put("paid",0.0); put("status","Recebido") }) }
    fun addTransaction(kind:String, desc:String, category:String, amount:Double, personal:Boolean) { writableDatabase.insertOrThrow("transactions", null, ContentValues().apply { put("kind",kind); put("description",desc); put("category",category); put("amount",amount); put("personal",if(personal) 1 else 0) }) }
    fun rows(sql:String): List<Map<String,String>> { val out= mutableListOf<Map<String,String>>(); readableDatabase.rawQuery(sql,null).use { c -> while(c.moveToNext()) { val m= mutableMapOf<String,String>(); for(i in 0 until c.columnCount) m[c.getColumnName(i)] = c.getString(i) ?: ""; out.add(m) } }; return out }
    fun scalar(sql:String): Double = readableDatabase.rawQuery(sql,null).use { if(it.moveToFirst()) it.getDouble(0) else 0.0 }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); val db=LocalDb(this); setContent { MaterialTheme(colorScheme = darkColorScheme(primary=Blue, background=Navy, surface=Panel, onBackground=White, onSurface=White)) { App(db) } } }
}

@Composable private fun App(db: LocalDb) {
    var tab by remember { mutableStateOf("Início") }; var refresh by remember { mutableIntStateOf(0) }; var showAdd by remember { mutableStateOf(false) }
    val customers = remember(refresh) { db.rows("SELECT * FROM customers ORDER BY id DESC") }
    val orders = remember(refresh) { db.rows("SELECT * FROM orders ORDER BY id DESC") }
    val tx = remember(refresh) { db.rows("SELECT * FROM transactions ORDER BY id DESC") }
    val income = remember(refresh) { db.scalar("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE kind='Entrada'") }
    val expenses = remember(refresh) { db.scalar("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE kind='Despesa'") }
    val pending = remember(refresh) { db.scalar("SELECT COALESCE(SUM(price-paid),0) FROM orders WHERE status!='Cancelado'") }
    Scaffold(containerColor=Navy, bottomBar = { NavigationBar(containerColor=Panel) { listOf("Início","Ordens","Clientes","Financeiro").forEach { t -> NavigationBarItem(selected=tab==t,onClick={tab=t},icon={ Icon(when(t){"Início"->Icons.Default.Dashboard;"Ordens"->Icons.Default.Build;"Clientes"->Icons.Default.People;else->Icons.Default.AccountBalanceWallet},null) },label={Text(t)}, colors=NavigationBarItemDefaults.colors(selectedIconColor=Blue, selectedTextColor=Blue, indicatorColor=Blue.copy(alpha=.15f), unselectedTextColor=Muted)) } } }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(horizontal=18.dp)) {
            Row(Modifier.fillMaxWidth().padding(top=18.dp,bottom=16.dp), verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("MD MASTER", color=White, fontSize=23.sp, fontWeight=FontWeight.Black); Text("UNLOCK  /  GESTÃO OFFLINE", color=Blue, fontSize=11.sp, letterSpacing=2.sp) }; Icon(Icons.Default.Bolt,null,tint=Blue,modifier=Modifier.size(34.dp)) }
            when(tab) {
                "Início" -> { Text("Visão geral", fontSize=22.sp, fontWeight=FontWeight.Bold); Text("Seus dados ficam salvos neste aparelho.",color=Muted,fontSize=12.sp); Spacer(Modifier.height(14.dp)); Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) { Metric("Entradas",money(income),Blue,Modifier.weight(1f)); Metric("Despesas",money(expenses),Color(0xFFFF7185),Modifier.weight(1f)) }; Spacer(Modifier.height(10.dp)); Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) { Metric("A receber",money(pending),Color(0xFFFFC857),Modifier.weight(1f)); Metric("Ordens",orders.size.toString(),Color(0xFF65D6A6),Modifier.weight(1f)) }; Spacer(Modifier.height(16.dp)); Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)) { Text("Movimento financeiro",fontWeight=FontWeight.Bold); Text("Entradas x despesas registradas",color=Muted,fontSize=12.sp); Spacer(Modifier.height(12.dp)); Canvas(Modifier.fillMaxWidth().height(100.dp)) { val maxV=maxOf(income,expenses,1.0); val base=size.height-8; val bw=size.width*.22f; drawRoundRect(Blue, Offset(size.width*.20f,base-(income/maxV*base).toFloat()), androidx.compose.ui.geometry.Size(bw,(income/maxV*base).toFloat()), cornerRadius=androidx.compose.ui.geometry.CornerRadius(12f)); drawRoundRect(Color(0xFFFF7185), Offset(size.width*.60f,base-(expenses/maxV*base).toFloat()), androidx.compose.ui.geometry.Size(bw,(expenses/maxV*base).toFloat()), cornerRadius=androidx.compose.ui.geometry.CornerRadius(12f)) }; Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly) { Text("● Entradas",color=Blue,fontSize=12.sp); Text("● Despesas",color=Color(0xFFFF7185),fontSize=12.sp) } } }; Spacer(Modifier.height(16.dp)); Text("Ordens recentes",fontWeight=FontWeight.Bold,fontSize=18.sp); Spacer(Modifier.height(8.dp)); if(orders.isEmpty()) EmptyState("Nenhuma ordem cadastrada ainda.") else LazyColumn { items(orders.take(4)) { OrderRow(it) } } }
                "Clientes" -> { SectionHeader("Clientes","Cadastre clientes localmente") { showAdd=true }; if(customers.isEmpty()) EmptyState("Sua lista de clientes está vazia.") else LazyColumn { items(customers) { Card(Modifier.fillMaxWidth().padding(bottom=8.dp),colors=CardDefaults.cardColors(containerColor=Panel)) { Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Person,null,tint=Blue); Spacer(Modifier.width(12.dp)); Column { Text(it["name"] ?: ""); Text(it["phone"] ?: "",color=Muted,fontSize=12.sp) } } } } } }
                "Ordens" -> { SectionHeader("Ordens de serviço","Acompanhe serviços e saldos") { showAdd=true }; if(orders.isEmpty()) EmptyState("Nenhuma ordem cadastrada ainda.") else LazyColumn { items(orders) { OrderRow(it) } } }
                else -> { SectionHeader("Financeiro","Registre entradas e despesas") { showAdd=true }; Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) { Metric("Entradas",money(income),Blue,Modifier.weight(1f)); Metric("Despesas",money(expenses),Color(0xFFFF7185),Modifier.weight(1f)) }; Spacer(Modifier.height(12.dp)); if(tx.isEmpty()) EmptyState("Nenhuma transação registrada.") else LazyColumn { items(tx) { Card(Modifier.fillMaxWidth().padding(bottom=8.dp),colors=CardDefaults.cardColors(containerColor=Panel)) { Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) { Icon(if(it["kind"]=="Entrada") Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,null,tint=if(it["kind"]=="Entrada") Blue else Color(0xFFFF7185)); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(it["description"] ?: ""); Text(it["category"] ?: "",color=Muted,fontSize=12.sp) }; Text(money((it["amount"]?:"0").toDoubleOrNull()?:0.0),fontWeight=FontWeight.Bold) } } } } }
            }
        }
    }
    if(showAdd) AddDialog(tab, db, { showAdd=false; refresh++ }, { showAdd=false })
}

@Composable private fun Metric(title:String,value:String,color:Color,modifier:Modifier=Modifier) { Card(modifier,colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(16.dp)) { Column(Modifier.padding(14.dp)) { Text(title,color=Muted,fontSize=12.sp); Spacer(Modifier.height(6.dp)); Text(value,color=color,fontSize=18.sp,fontWeight=FontWeight.Bold) } } }
@Composable private fun SectionHeader(title:String,sub:String,onAdd:()->Unit) { Row(Modifier.fillMaxWidth().padding(bottom=14.dp),verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(title,fontSize=22.sp,fontWeight=FontWeight.Bold); Text(sub,color=Muted,fontSize=12.sp) }; Button(onClick=onAdd,colors=ButtonDefaults.buttonColors(containerColor=Blue,contentColor=Navy)) { Icon(Icons.Default.Add,null); Text("Novo") } } }
@Composable private fun OrderRow(o:Map<String,String>) { Card(Modifier.fillMaxWidth().padding(bottom=8.dp),colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(14.dp)) { Column(Modifier.padding(14.dp)) { Row(verticalAlignment=Alignment.CenterVertically) { Text("OS #${o["id"]}",color=Blue,fontWeight=FontWeight.Bold); Spacer(Modifier.weight(1f)); Text(o["status"] ?: "Recebido",color=Color(0xFF65D6A6),fontSize=12.sp) }; Text(o["customer"] ?: "Cliente",fontWeight=FontWeight.SemiBold); Text("${o["device"]} · ${o["service"]}",color=Muted,fontSize=12.sp); Spacer(Modifier.height(5.dp)); Row { Text("Total ${money((o["price"]?:"0").toDoubleOrNull()?:0.0)}",fontSize=12.sp); Spacer(Modifier.width(12.dp)); Text("Pendente ${money(((o["price"]?:"0").toDoubleOrNull()?:0.0)-((o["paid"]?:"0").toDoubleOrNull()?:0.0))}",color=Color(0xFFFFC857),fontSize=12.sp) } } } }
@Composable private fun EmptyState(text:String) { Box(Modifier.fillMaxWidth().padding(top=36.dp),contentAlignment=Alignment.Center) { Column(horizontalAlignment=Alignment.CenterHorizontally) { Icon(Icons.Default.Inbox,null,tint=Muted,modifier=Modifier.size(38.dp)); Spacer(Modifier.height(8.dp)); Text(text,color=Muted) } } }

@Composable private fun AddDialog(tab:String, db:LocalDb, onSave:()->Unit, onDismiss:()->Unit) {
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var device by remember { mutableStateOf("") }; var service by remember { mutableStateOf("") }; var price by remember { mutableStateOf("") }; var desc by remember { mutableStateOf("") }; var category by remember { mutableStateOf("Serviços") }; var kind by remember { mutableStateOf("Entrada") }; var personal by remember { mutableStateOf(false) }; var error by remember { mutableStateOf("") }
    val customerMode = tab=="Clientes"; val orderMode=tab=="Ordens"; val title=if(customerMode) "Novo cliente" else if(orderMode) "Nova ordem de serviço" else "Nova transação"
    AlertDialog(onDismissRequest=onDismiss,containerColor=Panel,title={Text(title)},text={ Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
        if(customerMode) { OutlinedTextField(name,{name=it},label={Text("Nome completo")},singleLine=true); OutlinedTextField(phone,{phone=it},label={Text("Telefone")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Phone)) }
        else if(orderMode) { OutlinedTextField(name,{name=it},label={Text("Nome do cliente")},singleLine=true); OutlinedTextField(device,{device=it},label={Text("Aparelho / modelo")},singleLine=true); OutlinedTextField(service,{service=it},label={Text("Serviço solicitado")},singleLine=true); OutlinedTextField(price,{price=it},label={Text("Preço (R$)")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal)) }
        else { Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { FilterChip(selected=kind=="Entrada",onClick={kind="Entrada"},label={Text("Entrada")}); FilterChip(selected=kind=="Despesa",onClick={kind="Despesa"},label={Text("Despesa")}) }; OutlinedTextField(desc,{desc=it},label={Text("Descrição")},singleLine=true); OutlinedTextField(category,{category=it},label={Text("Categoria")},singleLine=true); OutlinedTextField(price,{price=it},label={Text("Valor (R$)")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal)); Row(verticalAlignment=Alignment.CenterVertically) { Checkbox(personal,{personal=it}); Text("Despesa pessoal") } }
        if(error.isNotBlank()) Text(error,color=Color(0xFFFF7185),fontSize=12.sp)
    } },confirmButton={ TextButton(onClick={ try { when { customerMode -> { if(name.isBlank()) throw IllegalArgumentException("Informe o nome."); db.addCustomer(name.trim(),phone.trim()) }; orderMode -> { val p=price.replace(",",".").toDoubleOrNull() ?: throw IllegalArgumentException("Informe um preço válido."); if(name.isBlank()||service.isBlank()) throw IllegalArgumentException("Informe cliente e serviço."); db.addOrder(name.trim(),device.trim(),service.trim(),p) }; else -> { val p=price.replace(",",".").toDoubleOrNull() ?: throw IllegalArgumentException("Informe um valor válido."); if(desc.isBlank()||p<=0) throw IllegalArgumentException("Informe descrição e valor maior que zero."); db.addTransaction(kind,desc.trim(),category.trim(),p,personal) } }; onSave() } catch(e:Exception) { error=e.message ?: "Não foi possível salvar." } }) { Text("Salvar") } },dismissButton={ TextButton(onClick=onDismiss) { Text("Cancelar") } })
}
